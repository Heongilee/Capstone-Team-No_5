// Firestore 초기화
// import firebase from 'firebase'
// import 'firebase/firestore'
// import firebaseConfig from './firebaseConfig'
// const firebaseApp = firebase.initializeApp(firebaseConfig)
// export default firebaseApp.firestore()
import * as firebase from "firebase/app";
import "firebase/firestore";
const myFireConfig = require('./firebaseConfig');